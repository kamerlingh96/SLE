<div class="row">
	<div class="col-md-8">
    	<div class="row">
            <!-- CALENDAR-->
            <div class="col-md-12 col-xs-12">
                <div class="panel panel-primary " data-collapsed="0">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <i class="fa fa-calendar"></i>
                            <?php echo get_phrase('event_schedule');?>
                        </div>
                    </div>
                    <div class="panel-body" style="padding:0px;">
                        <div class="calendar-env">
                            <div class="calendar-body">
                                <div id="notice_calendar"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

		<?php

		$month = date('m');

		if ($month == 1)
				$m = 'Enero';
		else if ($month == 2)
				$m = 'Febrero';
		else if ($month == 3)
				$m = 'Marzo';
		else if ($month == 4)
				$m = 'Abril';
		else if ($month == 5)
				$m = 'Mayo';
		else if ($month == 6)
				$m = 'Junio';
		else if ($month == 7)
				$m = 'Julio';
		else if ($month == 8)
				$m = 'Agosto';
		else if ($month == 9)
				$m = 'Septiembre';
		else if ($month == 10)
				$m = 'Octubre';
		else if ($month == 11)
				$m = 'Noviembre';
		else if ($month == 12)
				$m = 'Diciembre';

		 ?>

	<div class="col-md-4">
		<div class="row">

						<div class="col-md-12">

								<div class="tile-stats tile-green">
										<div class="icon"><i class="entypo-users"></i></div>
										<div class="num" style="font-size:20px;">"<?=$frases->frase?>"</div>

								</div>

						</div>

            <div class="col-md-12">

							<?php
							$year = explode('-', $running_year);
					    $days = cal_days_in_month(CAL_GREGORIAN, $month, $sessional_year);
							$data = array();

							$students = $this->db->get_where('enroll', array('student_id' => $student_id,'class_id' => $class_id, 'year' => $running_year, 'section_id' => $section_id))->result_array();
							if (sizeof($students) > 0):
								foreach ($students as $row):

								$status = 0;
								$recompensas = 0;


									for ($i = 1; $i <= $days; $i++) {
											$timestamp = strtotime($i . '-' . $month . '-' . $sessional_year);
											//$this->db->group_by('timestamp');
											$attendance = $this->db->get_where('attendance', array('section_id' => $section_id, 'class_id' => $class_id, 'year' => $running_year, 'timestamp' => $timestamp, 'student_id' => $row['student_id']))->result_array();

											foreach ($attendance as $row1):
													$month_dummy = date('d', $row1['timestamp']);

													if ($i == $month_dummy)
													$status = $row1['status'];
													$recompensa = $row1['recompensas'];
													$recompensas = $recompensas+$recompensa;


											endforeach;


										 }
									endforeach;
								 endif; ?>

                <div class="tile-stats tile-red">
                    <div class="icon"><i class="fa fa-group"></i></div>
                    <div class="num" data-start="0" data-end="<?php echo $recompensas;?>"
                    		data-postfix="" data-duration="1500" data-delay="0">0</div>

                    <h3><?php echo get_phrase('recompensas');?></h3>
                   <p>Mes de <?php echo $m; ?></p>
                </div>

            </div>

            <div class="col-md-12">

                <div class="tile-stats tile-aqua">
                    <div class="icon"><i class="entypo-user"></i></div>
                    <div class="num" data-start="0" data-end="<?php echo $this->db->count_all('parent');?>"
                    		data-postfix="" data-duration="500" data-delay="0">0</div>

                    <h3><?php echo get_phrase('parent');?></h3>
                   <p>Total de padres</p>
                </div>

            </div>
            <div class="col-md-12">

                <div class="tile-stats tile-blue">
                    <div class="icon"><i class="entypo-chart-bar"></i></div>
                    <?php
						$check   =   array(  'timestamp' => strtotime(date('Y-m-d')) , 'status' => '1' );
                        $query = $this->db->get_where('attendance' , $check);
                        $present_today      =   $query->num_rows();
						?>
                    <div class="num" data-start="0" data-end="<?php echo $present_today;?>"
                    		data-postfix="" data-duration="500" data-delay="0">0</div>

                    <h3><?php echo get_phrase('attendance');?></h3>
                   <p>Total de estudiantes presentes hoy</p>
                </div>

            </div>
    	</div>
    </div>

</div>



    <script>
  $(document).ready(function() {

	  var calendar = $('#notice_calendar');

				$('#notice_calendar').fullCalendar({
					header: {
						left: 'title',
						right: 'today prev,next'
					},
					buttonText:{
						today: 'hoy'
					},
					monthNames:[
						'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio',
  					'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
					],
					dayNamesShort:[
						'Dom', 'Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab'
					],

					//defaultView: 'basicWeek',

					editable: false,
					firstDay: 1,
					height: 530,
					droppable: false,

					events: [
						<?php
						$notices	=	$this->db->get('noticeboard')->result_array();
						foreach($notices as $row):
						?>
						{
							title: "<?php echo $row['notice_title'];?>",
							start: new Date(<?php echo date('Y',$row['create_timestamp']);?>, <?php echo date('m',$row['create_timestamp'])-1;?>, <?php echo date('d',$row['create_timestamp']);?>),
							end:	new Date(<?php echo date('Y',$row['create_timestamp']);?>, <?php echo date('m',$row['create_timestamp'])-1;?>, <?php echo date('d',$row['create_timestamp']);?>)
						},
						<?php
						endforeach
						?>

					]
				});
	});
  </script>
